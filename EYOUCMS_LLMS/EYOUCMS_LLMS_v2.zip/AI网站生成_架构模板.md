# AI 网站生成 - 架构模板

> 展示两种网站类型的完整文件结构和每个页面的模块组成。

---

## 一、内容发布网站架构

### 1.1 文件结构

```
html/
│
├── index.htm              ← 首页（3个栏目模块 + 1-3个额外模块）
├── lists_article.htm      ← 文章列表页
├── lists_article_small.htm ← 窄型文章列表（条款、协议）
├── lists_single.htm       ← 单页面（关于我们）
├── lists_search.htm       ← 搜索列表页
├── view_article.htm       ← 文章详情页
│
├── nav.htm                ← 导航栏（已有，勿修改）
├── footer.htm             ← 底部（已有，勿修改）
└── header.htm             ← 头部框架（已有，勿修改）
```

### 1.2 栏目结构

```
顶级导航
├── 栏目A（文章模型，ID=4）
│   ├── 文章1
│   ├── 文章2
│   └── ...
├── 栏目B（文章模型，ID=5）
│   ├── 文章1
│   ├── 文章2
│   └── ...
├── 栏目C（文章模型，ID=6）
│   ├── 文章1
│   ├── 文章2
│   └── ...
└── 关于我们（单页模型，ID=7）
    ├── 子单页1
    └── 子单页2
```

### 1.3 首页模块组成

```
┌─────────────────────────────────────────────────────────┐
│                     header.htm                          │
├─────────────────────────────────────────────────────────┤
│                     nav.htm                            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块1】Banner 轮播                       │
│              （可选，使用 {eyou:adv pid='1'}）          │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块2】栏目A 内容模块                     │
│              （必选，使用 {eyou:artlist typeid='4'}）   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块3】栏目B 内容模块                     │
│              （必选，使用 {eyou:artlist typeid='5'}）   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块4】栏目C 内容模块                     │
│              （必选，使用 {eyou:artlist typeid='6'}）   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块5】服务优势（可选）                   │
│              （4个优势点展示）                          │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块6】合作伙伴（可选）                   │
│              （使用 {eyou:links type='image'}）         │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                     footer.htm                         │
└─────────────────────────────────────────────────────────┘
```

### 1.4 列表页结构

```
┌─────────────────────────────────────────────────────────┐
│                     header.htm                          │
├─────────────────────────────────────────────────────────┤
│                     nav.htm                            │
├─────────────────────────────────────────────────────────┤
│ 面包屑：{eyou:position style='crumb'}                  │
├─────────────────────────────────────────────────────────┤
│ 栏目标题：{eyou:type}                                  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                │
│  │ 文章1   │  │ 文章2   │  │ 文章3   │                │
│  └─────────┘  └─────────┘  └─────────┘                │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                │
│  │ 文章4   │  │ 文章5   │  │ 文章6   │                │
│  └─────────┘  └─────────┘  └─────────┘                │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  分页：{eyou:pagelist}                                 │
├─────────────────────────────────────────────────────────┤
│                     footer.htm                         │
└─────────────────────────────────────────────────────────┘
```

### 1.5 详情页结构

```
┌─────────────────────────────────────────────────────────┐
│                     header.htm                          │
├─────────────────────────────────────────────────────────┤
│                     nav.htm                            │
├─────────────────────────────────────────────────────────┤
│ 面包屑：{eyou:position style='crumb'}                  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  文章标题：{$eyou.field.title}                          │
│  发布时间：{$eyou.field.add_time}                      │
│  点击量：{eyou:arcclick}                               │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  文章正文：{$eyou.field.content}                        │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  标签：{eyou:tags}                                     │
├─────────────────────────────────────────────────────────┤
│  上一篇/下一篇：{eyou:beafter}                         │
├─────────────────────────────────────────────────────────┤
│  相关推荐：{eyou:relevarticle}                          │
├─────────────────────────────────────────────────────────┤
│                     footer.htm                         │
└─────────────────────────────────────────────────────────┘
```

---

## 二、商城网站架构

### 2.1 文件结构

```
html/
│
├── index.htm              ← 首页（3个产品模块 + 1-3个额外模块）
├── lists_product.htm      ← 产品列表页
├── lists_article_small.htm ← 窄型文章列表（服务条款、协议）
├── lists_single.htm       ← 单页面（如有）
├── lists_search.htm       ← 搜索列表页
├── view_product.htm       ← 产品详情页
├── view_article.htm       ← 服务详情页
│
├── nav.htm                ← 导航栏（已有，勿修改）
├── footer.htm             ← 底部（已有，勿修改）
└── header.htm             ← 头部框架（已有，勿修改）
```

### 2.2 栏目结构

```
顶级导航
├── 产品栏目A（产品模型，ID=1）
│   ├── 产品1
│   ├── 产品2
│   └── ...
├── 产品栏目B（产品模型，ID=2）
│   ├── 产品1
│   ├── 产品2
│   └── ...
├── 产品栏目C（产品模型，ID=3）
│   ├── 产品1
│   ├── 产品2
│   └── ...
└── 服务（文章模型，含子栏目）
    ├── 服务条款
    ├── 隐私政策
    └── 配送说明
```

### 2.3 首页模块组成

```
┌─────────────────────────────────────────────────────────┐
│                     header.htm                          │
├─────────────────────────────────────────────────────────┤
│                     nav.htm                            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块1】Banner 轮播                       │
│              （可选，使用 {eyou:adv pid='1'}）          │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块2】产品栏目A 展示                     │
│              （必选，使用 {eyou:artlist typeid='1'}）   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块3】产品栏目B 展示                    │
│              （必选，使用 {eyou:artlist typeid='2'}）   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块4】产品栏目C 展示                    │
│              （必选，使用 {eyou:artlist typeid='3'}）   │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块5】服务保障（可选）                   │
│              （4个保障点展示）                          │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│              【模块6】合作伙伴（可选）                   │
│              （使用 {eyou:links type='image'}）         │
│                                                         │
├─────────────────────────────────────────────────────────┤
│                     footer.htm                         │
└─────────────────────────────────────────────────────────┘
```

### 2.4 产品列表页结构

```
┌─────────────────────────────────────────────────────────┐
│                     header.htm                          │
├─────────────────────────────────────────────────────────┤
│                     nav.htm                            │
├─────────────────────────────────────────────────────────┤
│ 面包屑：{eyou:position style='crumb'}                  │
├─────────────────────────────────────────────────────────┤
│ 栏目标题：{eyou:type}                                  │
├─────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐   │
│  │ 产品1   │  │ 产品2   │  │ 产品3   │  │ 产品4   │   │
│  │ ¥价格   │  │ ¥价格   │  │ ¥价格   │  │ ¥价格   │   │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘   │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐   │
│  │ 产品5   │  │ 产品6   │  │ 产品7   │  │ 产品8   │   │
│  │ ¥价格   │  │ ¥价格   │  │ ¥价格   │  │ ¥价格   │   │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘   │
├─────────────────────────────────────────────────────────┤
│  分页：{eyou:pagelist}                                 │
├─────────────────────────────────────────────────────────┤
│                     footer.htm                         │
└─────────────────────────────────────────────────────────┘
```

### 2.5 产品详情页结构

```
┌─────────────────────────────────────────────────────────┐
│                     header.htm                          │
├─────────────────────────────────────────────────────────┤
│                     nav.htm                            │
├─────────────────────────────────────────────────────────┤
│ 面包屑：{eyou:position style='crumb'}                  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌───────────────────┐  ┌─────────────────────────┐  │
│  │                   │  │  产品标题：{$eyou.field} │  │
│  │   产品图片         │  │                         │  │
│  │                   │  │  购买组件：              │  │
│  │   {$eyou.field}   │  │  {eyou:sppurchase}      │  │
│  │                   │  │                         │  │
│  │                   │  │  商品参数：              │  │
│  │                   │  │  {eyou:attribute}        │  │
│  └───────────────────┘  └─────────────────────────┘  │
│                                                         │
├─────────────────────────────────────────────────────────┤
│  产品详情：{$eyou.field.content}                       │
├─────────────────────────────────────────────────────────┤
│  商品评价：{eyou:comment}                              │
├─────────────────────────────────────────────────────────┤
│  上一篇/下一篇：{eyou:beafter}                         │
├─────────────────────────────────────────────────────────┤
│                     footer.htm                         │
└─────────────────────────────────────────────────────────┘
```

---

## 三、额外模块详解

### 3.1 Banner 轮播模块

```
适用场景：任何网站类型
推荐指数：★★★★★（几乎必选）
标签：{eyou:adv pid='1'}

结构：
┌─────────────────────────────────────────────────────────┐
│                                                         │
│     ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐     │
│     │  轮播1  │ │  轮播2  │ │  轮播3  │ │  轮播4  │     │
│     └─────────┘ └─────────┘ └─────────┘ └─────────┘     │
│                                                         │
│  ◀ 按钮                    指示点                    ▶  │
└─────────────────────────────────────────────────────────┘
```

### 3.2 服务优势模块

```
适用场景：企业官网、服务类网站
推荐指数：★★★★☆
标签：无（静态内容或 {eyou:artlist flag='c'} 推荐文档）

结构：
┌─────────────────────────────────────────────────────────┐
│                      为什么选择我们                       │
├──────────────┬──────────────┬──────────────┬────────────┤
│    优势1     │    优势2     │    优势3     │   优势4   │
│    图标      │    图标      │    图标      │   图标    │
│    标题      │    标题      │    标题      │   标题    │
│    描述      │    描述      │    描述      │   描述    │
└──────────────┴──────────────┴──────────────┴────────────┘
```

### 3.3 合作伙伴模块

```
适用场景：任何网站类型
推荐指数：★★★★☆
标签：{eyou:links type='image'}

结构：
┌─────────────────────────────────────────────────────────┐
│                        合作伙伴                         │
├─────────────────────────────────────────────────────────┤
│  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐        │
│  │ Logo │  │ Logo │  │ Logo │  │ Logo │  │ Logo │        │
│  └─────┘  └─────┘  └─────┘  └─────┘  └─────┘        │
└─────────────────────────────────────────────────────────┘
```

### 3.4 统计数据模块

```
适用场景：企业官网、服务类网站
推荐指数：★★★☆☆
标签：无（静态内容）

结构：
┌─────────────────────────────────────────────────────────┐
│                        10+        500+        1000+        │
│                       年行业经验    服务客户    完成项目        │
└─────────────────────────────────────────────────────────┘
```

### 3.5 关于我们入口模块

```
适用场景：任何网站类型
推荐指数：★★★★☆
标签：{eyou:type typeid='7'}（单页栏目ID）

结构：
┌─────────────────────────────────────────────────────────┐
│  ┌───────────────────┐                                  │
│  │                   │   ABOUT US                       │
│  │   关于我们图片     │   关于我们                        │
│  │                   │   简介描述...                      │
│  │                   │   了解更多 →                      │
│  └───────────────────┘                                  │
└─────────────────────────────────────────────────────────┘
```

### 3.6 留言咨询入口模块

```
适用场景：任何网站类型
推荐指数：★★★☆☆
标签：{eyou:guestbookform} 或 {eyou:form}

结构：
┌─────────────────────────────────────────────────────────┐
│                        立即咨询                          │
│            有任何问题或需求？欢迎随时联系我们                  │
│                                                         │
│         ┌──────────────┐  ┌──────────────┐            │
│         │  在线留言    │  │  电话咨询    │            │
│         └──────────────┘  └──────────────┘            │
└─────────────────────────────────────────────────────────┘
```

---

## 四、模块组合推荐

### 4.1 内容发布网站

| 组合 | 模块配置 | 适用场景 |
|------|---------|---------|
| 基础版 | 3个栏目模块 | 简单展示，无需额外模块 |
| 标准版 | Banner + 3个栏目模块 | 大多数企业站 |
| 完整版 | Banner + 3个栏目模块 + 服务优势 + 合作伙伴 | 完整企业站 |

### 4.2 商城网站

| 组合 | 模块配置 | 适用场景 |
|------|---------|---------|
| 基础版 | 3个产品模块 | 简单展示，无需额外模块 |
| 标准版 | Banner + 3个产品模块 + 服务保障 | 大多数商城 |
| 完整版 | Banner + 3个产品模块 + 服务保障 + 合作伙伴 | 完整商城 |

---

## 五、首页模块生成顺序

### 5.1 完整版首页生成顺序

1. **header.htm 引用**
2. **nav.htm 引用**
3. **Banner 轮播模块**（如果选择）
4. **栏目A 内容模块**（必选，typeid=4 或 typeid=1）
5. **栏目B 内容模块**（必选，typeid=5 或 typeid=2）
6. **栏目C 内容模块**（必选，typeid=6 或 typeid=3）
7. **服务优势/统计数据模块**（如果选择）
8. **合作伙伴模块**（如果选择）
9. **关于我们/留言咨询模块**（如果选择）
10. **footer.htm 引用**
11. **Swiper 初始化脚本**

### 5.2 模块代码位置示意

```html
<!DOCTYPE html>
<html>
<head>
  {eyou:include file="header.htm" /}
  <style type="text/tailwindcss">
    /* 页面级样式 */
  </style>
  <style>
    /* 自定义样式 */
  </style>
</head>
<body>
  <!-- nav -->
  {eyou:include file="nav.htm" /}
  <!-- nav -->

  <!-- Banner 轮播模块（可选） -->
  <section id="block-banner">
    ...
  </section>

  <!-- 栏目A 内容模块（必选） -->
  <section id="block-category-1">
    ...
  </section>

  <!-- 栏目B 内容模块（必选） -->
  <section id="block-category-2">
    ...
  </section>

  <!-- 栏目C 内容模块（必选） -->
  <section id="block-category-3">
    ...
  </section>

  <!-- 服务优势模块（可选） -->
  <section id="block-features">
    ...
  </section>

  <!-- 合作伙伴模块（可选） -->
  <section id="block-partners">
    ...
  </section>

  <!-- footer -->
  {eyou:include file="footer.htm" /}
  <!-- footer -->
  <script>
    (function () {
      // Swiper 初始化
      new Swiper('#block-banner .swiper', {
        // 配置
      });
    })();
  </script>
</body>
</html>
```

---

## 六、栏目内容模块通用模板

### 6.1 内容发布 - 文章模块（通用）

```html
<section id="block-category-{N}" class="w-full py-16">
  <div class="max-w-6xl mx-auto">
    <!-- 栏目标题区 -->
    <div class="text-center mb-12">
      <h2 class="text-2xl font-bold text-gray-800">
        {eyou:type typeid='{栏目ID}' id='t'}{$t.typename}{/eyou:type}
      </h2>
      <p class="text-gray-500 mt-3">
        {eyou:type typeid='{栏目ID}' id='t'}{$t.seo_description|html_msubstr=###,0,80,true}{/eyou:type}
      </p>
    </div>

    <!-- 内容列表区 -->
    <div class="grid grid-cols-3 gap-8">
      {eyou:artlist typeid='{栏目ID}' loop='6' titlelen='30' infolen='80' orderby='add_time' id='field'}
      <article class="card bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
        <a href='{$field.arcurl}' class="block">
          {eyou:notempty name='$field.litpic'}
          <div class="aspect-video overflow-hidden">
            <img src='{$field.litpic}' alt='{$field.title}' class="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
          </div>
          {/eyou:notempty}
          <div class="p-4">
            <h3 class="text-lg font-medium text-gray-800 mb-2 line-clamp-2 hover:text-primary transition-colors">
              {$field.title}
            </h3>
            {eyou:notempty name='$field.description'}
            <p class="text-sm text-gray-500 mb-2 line-clamp-3">
              {$field.description|html_msubstr=###,0,80,true}
            </p>
            {/eyou:notempty}
            <div class="flex items-center justify-between text-xs text-gray-400">
              <span><i class="fa-solid fa-calendar mr-1"></i>{$field.add_time|MyDate='Y-m-d',###}</span>
              <span><i class="fa-solid fa-eye mr-1"></i>{$field.click}</span>
            </div>
          </div>
        </a>
      </article>
      {/eyou:artlist}
    </div>

    <!-- 查看更多按钮 -->
    <div class="text-center mt-10">
      <a href='/{eyou:type typeid='{栏目ID}' id='t'}{$t.typeurl}{/eyou:type}'
         class="inline-flex items-center px-8 py-3 border-2 border-primary text-primary hover:bg-primary hover:text-white transition-colors duration-300">
        查看更多 <i class="fa-solid fa-arrow-right ml-2"></i>
      </a>
    </div>
  </div>
</section>
```

### 6.2 商城 - 产品模块（通用）

```html
<section id="block-product-{N}" class="w-full py-16">
  <div class="max-w-6xl mx-auto">
    <!-- 栏目标题区 -->
    <div class="text-center mb-12">
      <h2 class="text-2xl font-bold text-gray-800">
        {eyou:type typeid='{栏目ID}' id='t'}{$t.typename}{/eyou:type}
      </h2>
      <p class="text-gray-500 mt-3">
        {eyou:type typeid='{栏目ID}' id='t'}{$t.seo_description|html_msubstr=###,0,80,true}{/eyou:type}
      </p>
    </div>

    <!-- 产品列表区 -->
    <div class="grid grid-cols-4 gap-6">
      {eyou:artlist typeid='{栏目ID}' loop='8' titlelen='30' infolen='60' orderby='add_time' id='field'}
      <article class="product-card bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
        <a href='{$field.arcurl}' class="block">
          {eyou:notempty name='$field.litpic'}
          <div class="aspect-square overflow-hidden bg-gray-100">
            <img src='{$field.litpic}' alt='{$field.title}' class="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
          </div>
          {/eyou:notempty}
          <div class="p-4">
            <h3 class="text-sm font-medium text-gray-800 mb-2 line-clamp-2 hover:text-primary transition-colors">
              {$field.title|text_msubstr=###,0,30,true}
            </h3>
            {eyou:arcview aid='$field.aid' id='price'}
            <div class="text-lg font-bold text-primary">
              <i class="fa-solid fa-yen-sign text-sm mr-1"></i>{$price.users_price}
            </div>
            {/eyou:arcview}
          </div>
        </a>
      </article>
      {/eyou:artlist}
    </div>

    <!-- 查看更多按钮 -->
    <div class="text-center mt-10">
      <a href='/{eyou:type typeid='{栏目ID}' id='t'}{$t.typeurl}{/eyou:type}'
         class="inline-flex items-center px-8 py-3 border-2 border-primary text-primary hover:bg-primary hover:text-white transition-colors duration-300">
        查看更多 <i class="fa-solid fa-arrow-right ml-2"></i>
      </a>
    </div>
  </div>
</section>
```

---

## 七、页面类型速查表

| 页面类型 | 文件名 | 内容发布网站 | 商城网站 |
|---------|--------|------------|---------|
| 首页 | `index.htm` | ✅ 必做 | ✅ 必做 |
| 文章列表 | `lists_article.htm` | ✅ 必做 | ❌ |
| 产品列表 | `lists_product.htm` | ❌ | ✅ 必做 |
| 文章详情 | `view_article.htm` | ✅ 必做 | ✅（服务详情） |
| 产品详情 | `view_product.htm` | ❌ | ✅ 必做 |
| 窄型文章列表 | `lists_article_small.htm` | ❌ | ✅ 必做 |
| 单页面 | `lists_single.htm` | ✅（关于我们） | ✅（如有） |
| 搜索页 | `lists_search.htm` | ✅ 必做 | ✅ 必做 |
| 导航栏 | `nav.htm` | 已存在 | 已存在 |
| 底部 | `footer.htm` | 已存在 | 已存在 |
| 头部 | `header.htm` | 已存在 | 已存在 |

---

## 八、栏目 ID 速查表

### 内容发布网站

| 栏目 | 模型 | 栏目ID | 说明 |
|------|------|--------|------|
| 栏目A | 文章模型 | 4 | typeid='4' |
| 栏目B | 文章模型 | 5 | typeid='5' |
| 栏目C | 文章模型 | 6 | typeid='6' |
| 关于我们 | 单页模型 | 7 | typeid='7' |

### 商城网站

| 栏目 | 模型 | 栏目ID | 说明 |
|------|------|--------|------|
| 产品栏目A | 产品模型 | 1 | typeid='1' |
| 产品栏目B | 产品模型 | 2 | typeid='2' |
| 产品栏目C | 产品模型 | 3 | typeid='3' |
| 服务 | 文章模型 | - | 使用 lists_article_small.htm |

---

## 九、标签使用速查

### 首页常用标签

| 用途 | 内容发布网站 | 商城网站 |
|------|------------|---------|
| 栏目文章列表 | `{eyou:artlist typeid='4'}` | `{eyou:artlist typeid='1'}` |
| 广告轮播 | `{eyou:adv pid='1'}` | `{eyou:adv pid='1'}` |
| 图片友链 | `{eyou:links type='image'}` | `{eyou:links type='image'}` |
| 单页入口 | `{eyou:type typeid='7'}` | - |
| 产品价格 | - | `{eyou:arcview}` |

### 列表页常用标签

| 用途 | 标签 |
|------|------|
| 文档列表 | `{eyou:list loop='N'}` |
| 分页 | `{eyou:pagelist}` |
| 面包屑 | `{eyou:position style='crumb'}` |
| 栏目标题 | `{eyou:type id='cate'}{$cate.typename}{/eyou:type}` |

### 详情页常用标签

| 用途 | 标签 |
|------|------|
| 标题 | `{$eyou.field.title}` |
| 正文 | `{$eyou.field.content}` |
| 缩略图 | `{$eyou.field.litpic}` |
| 发布时间 | `{$eyou.field.add_time|MyDate='Y-m-d',###}` |
| 购买组件 | `{eyou:sppurchase}` |
| 上下篇 | `{eyou:beafter}` |
| 相关文档 | `{eyou:relevarticle}` |
